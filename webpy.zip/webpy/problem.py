class problem:
  content=""
  lists={}
  constants={}
  def __init__(self, content,listpairs, constants,dimensions,solution):
    self.content=content
    self.lists={}
    self.lists=listpairs
    self.constants={}
    self.constants=constants
    
    self.dimensions=dimensions
    self.solution=solution
  
