class solutioninstance:
  def __init__(self,table):
    self.show=False
    self.table=table
